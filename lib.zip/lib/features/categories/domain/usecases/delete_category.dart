import 'package:expense_tracker/domain/repositories/category_repository.dart';

class DeleteCategory {
  final CategoryRepository repository;

  DeleteCategory(this.repository);

  Future<void> call(int id) {
    return repository.deleteCategory(id);
  }
}